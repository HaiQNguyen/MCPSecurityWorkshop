/*
 * SecureFunctions.h
 *
 * Created: 01/07/2019 12:32:06
 *  Author: haing
 */ 


#ifndef SECUREFUNCTIONS_H_
#define SECUREFUNCTIONS_H_

#include <atmel_start.h>

void secure_console_puts (uint8_t * string);
void non_secure_console_puts (uint8_t * string);
void SymmetricAuthentication(void);
bool IsAuthenticated(void);
uint8_t APIInTrustZone(int * a, int * b, int * sum);


#endif /* SECUREFUNCTIONS_H_ */