

/** @file SecureAuthentication.h
 *  @brief Contain the header of secure functions
 *
 *	These function can be call directly by the secure application
 *	or indirectly thru a veneer table by the non-secure application
 *
 *	@author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */

#ifndef SECUREAUTHENTICATION_H_
#define SECUREAUTHENTICATION_H_

#include <atmel_start.h>

//TODO 1 - secure functions header


#endif /* SECUREAUTHENTICATION_H_ */