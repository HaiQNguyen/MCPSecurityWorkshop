
/** @file SecureAuthentication.c
 *  @brief Contain the secure functions
 *
 *	These function can be call directly by the secure application
 *	or indirectly thru a veneer table by the non-secure application
 *
 *	@author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */

#include "Secure_functions/SecureAuthentication.h" 
#include "cryptoauthlib.h"
#include "atca_host.h"

//TODO 2 - secure functions body

