/** @file main.c
 *  @brief main file for the secure application
 *
 *  This file content the initialization code for the secure application
 *	and non-secure application.
 *
 *	@author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */


#include <atmel_start.h>
#include "Secure_functions/SecureAuthentication.h"


/* Define section ---------------------------------------------------*/

//TODO 5 - secure app, declaration 


int main(void)
{
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//TODO 6 - Initialize non-secure application
	
	/* Replace with your application code */
	while (1) {
	}
}


