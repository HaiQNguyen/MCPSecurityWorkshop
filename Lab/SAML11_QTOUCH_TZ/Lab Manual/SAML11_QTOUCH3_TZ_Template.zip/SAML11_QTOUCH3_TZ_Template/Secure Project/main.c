
/** @file main.c
 *  @brief main function, entry point of the application.  
 *
 *	Trusted application. Handling and verifying the pass code from the keypad 
 *
 *  @author Quang Hai Nguyen - TFAE- Engineering DACH - Arrow Central Europe GmbH 
 *
 *	@date	01.06.2019 - initial 
 *
 *  @bug No known bugs.
 */

/* Include section ----------------------------------------------------------*/
#include <atmel_start.h>
#include <string.h>



/* define section ----------------------------------------------------------*/
//TODO 1 - define section

			
/* external variable section ----------------------------------------------------------*/
//TODO 2 - external variable


/* local variable section -------------------------------------------------------------*/
//TODO 3 - local variable


/* local function section -------------------------------------------------------------*/
//TODO 4 - Local function



int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	//TODO 5 - intialize and start timer 
	

	/* Replace with your application code */
	while (1) {
		
	}
}


// TODO 6 - Local function body