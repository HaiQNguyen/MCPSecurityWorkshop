
/** @file main.c
 *  @brief main file for the secure application
 *
 *  This file content the initialization code for the secure application
 *	and non-secure application. NOTE RTC and tamper pin PA08 will be initialized 
 *	manually because they are not correctly supported by Atmel START
 *
 *	@author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */


#include <atmel_start.h>
#include "Secure_functions/Secure_Functions.h"
#include "cryptoauthlib.h"
#include "atca_host.h"



/* Define section -----------------------------------------------------------------------*/
//TODO 5 - Secure app, define section, local variable and function prototype  



int main(void)
{
	//TODO 6 - Secure app, variable initialize
	 
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//TODO 7 - Secure app, init TrustRAM, ATECC508, Write data to TrustRAM 
	
	//TODO 8 - Secure app, start non-secure application

	
	/* Replace with your application code */
	while (1) {
		
		
	}
}

//TODO 9 - Secure app, function body
static void print_bytes(uint8_t * ptr, uint8_t length)
{
	
	uint8_t i = 0;
	uint8_t line_count = 0;
	for(;i < length; i++) {
		printf("0x%02x, ",ptr[i]);
		line_count++;
		if(line_count == 8) {
			printf("\r\n");
			line_count = 0;
		}
	}
	
	printf("\r\n");
}
