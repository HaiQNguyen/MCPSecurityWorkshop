
/** @file Secure_Funcion.h
 *  @brief Header file of Secure_Function.c  
 *
 *	Contain global functions and variables to be called 
 *
 *  @author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */

#include <atmel_start.h>

#ifndef SECURE_FUNCTIONS_H_
#define SECURE_FUNCTIONS_H_

//TODO 1 - Secure functions header


#endif /* SECURE_FUNCTIONS_H_ */