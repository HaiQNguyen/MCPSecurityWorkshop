
/** @file Secure_Funcion.c
 *  @brief Implement the secure functions.  
 *
 *	Some of the functions will be share with the non-secure application
 *	through veneer table
 *
 *  @author Quang Hai Nguyen
 *
 *	@date	29.05.2019 - initial 
 *
 *  @bug No known bugs.
 */

#include "Secure_Functions.h"
#include "sam.h"

//TODO 2 - Secure functions body
