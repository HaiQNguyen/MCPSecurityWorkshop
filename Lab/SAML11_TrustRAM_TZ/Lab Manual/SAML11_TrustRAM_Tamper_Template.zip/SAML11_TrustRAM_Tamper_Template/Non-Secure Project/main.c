
/* Include section-----------------------------------------------------------------------------------*/
#include <atmel_start.h>
#include "trustzone_veneer.h"

//TODO 10 - Non-secure app, variable initialize


int main(void)
{
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	//TODO 11 - Non-secure app
}
