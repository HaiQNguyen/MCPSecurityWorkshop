#include <atmel_start.h>

void my_touch_status_display(void);

/*----------------------------------------------------------------------------
 *   Extern variables
 *----------------------------------------------------------------------------*/
extern volatile uint8_t measurement_done_touch;

/*----------------------------------------------------------------------------
 *   Global variables
 *----------------------------------------------------------------------------*/
uint8_t key_pressed = 0;
uint8_t key_press_count[12];


static struct timer_task touch_timer;



static void TouchTimer_CB(const struct timer_task *const timer_task);

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	
	touch_timer.interval = 5;
	touch_timer.cb       = TouchTimer_CB;
	touch_timer.mode     = TIMER_TASK_REPEAT;


	timer_add_task(&Timer, &touch_timer);
	timer_start(&Timer);
	
	
	printf("Hi \r\n");
	/* Replace with your application code */
	while (1) {
		
	}
}


void my_touch_status_display(void)
{
	for(uint8_t i = 0; i < 12; i++)
	{
		key_pressed = get_sensor_state(i) & KEY_TOUCHED_MASK;
		if (0u != key_pressed) {
			// LED_ON
			++key_press_count[i];
			if(key_press_count[i] >=20)
			{
				key_press_count[i] = 0;
				printf("Button %d is pressed \r\n", i + 1);
			}
		}
		else {
			// LED_OFF
		}
	}
}

static void TouchTimer_CB(const struct timer_task *const timer_task)
{

	touch_process();
	if (measurement_done_touch == 1) {
		my_touch_status_display();
	}
}