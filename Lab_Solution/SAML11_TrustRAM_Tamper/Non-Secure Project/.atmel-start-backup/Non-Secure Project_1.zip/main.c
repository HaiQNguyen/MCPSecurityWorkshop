#include <atmel_start.h>
#include "trustzone_veneer.h"

int main(void)
{
	uint8_t rev[4];
	uint8_t ser[9];
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	nonsecure_ConsolePuts("Hello World from non secure\r\n");
	
	
	/* Replace with your application code */
	while (1) {
		nonsecure_ConsolePuts("\r\n\r\n");
		nonsecure_ConsolePuts("Calling and print serial number and revision\r\n");
		nonsecure_GetRevSerialNumber(ser, 9, rev, 4);
		nonsecure_ConsolePuts("Serial number: \r\n");
		nonsecure_PrintBytes(ser, 9);
		nonsecure_ConsolePuts("Revision number: \r\n");
		nonsecure_PrintBytes(rev, 4);
		delay_ms(2000);
	}
}
