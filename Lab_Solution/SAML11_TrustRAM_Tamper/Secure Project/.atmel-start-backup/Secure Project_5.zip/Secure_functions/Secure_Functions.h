/*
 * Secure_Functions.h
 *
 * Created: 22/05/2019 13:41:04
 *  Author: haing
 */ 

#include <atmel_start.h>

#ifndef SECURE_FUNCTIONS_H_
#define SECURE_FUNCTIONS_H_


void sc_RTC_Init(void);
void sc_TRAM_Fill(uint8_t patern);
void sc_TRAM_Init(void);



#endif /* SECURE_FUNCTIONS_H_ */