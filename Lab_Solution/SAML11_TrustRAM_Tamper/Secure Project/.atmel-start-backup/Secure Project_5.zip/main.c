#include <atmel_start.h>
#include "Secure_functions/Secure_Functions.h"


/* NOTE RTC and tamper pin PA08 will be initialized manually because they are not supported by Atmel START*/




int main(void)
{
	int i;
	uint8_t *addr_b;
	addr_b = (uint8_t*)&TRAM->RAM[0].reg;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	printf("helllo world\r\n");
	
	sc_RTC_Init();
	sc_TRAM_Init();
	sc_TRAM_Fill(0x05);
	
	
	/* Replace with your application code */
	while (1) {
		
		delay_ms(2000);
		for (i=0; i < 128; i=i+2)
		{
			if (i%16 == 0)
			{
				printf("\r\n");
			}
			printf("0x%02x%02x ",*(addr_b+i),*(addr_b+i+1));
		}
	}
}

