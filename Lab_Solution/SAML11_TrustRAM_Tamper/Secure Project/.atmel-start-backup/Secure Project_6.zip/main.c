#include <atmel_start.h>
#include "Secure_functions/Secure_Functions.h"
#include "cryptoauthlib.h"
#include "atca_host.h"

/* NOTE RTC and tamper pin PA08 will be initialized manually because they are not supported by Atmel START*/


/* Define section ---------------------------------------------------*/
#define CHECK_STATUS(s)										\
if(s != ATCA_SUCCESS) {										\
	printf("status code: 0x%x\r\n", s);						\
	printf("Error: Line %d in %s\r\n", __LINE__, __FILE__); \
	while(1);												\
}


/* Local variable section --------------------------------------------*/
ATCAIfaceCfg cfg_ateccx08a_i2c_host = {
	.iface_type				= ATCA_I2C_IFACE,
	.devtype				= ATECC508A,
	.atcai2c.slave_address	= 0xC0,
	.atcai2c.bus			= 1,
	.atcai2c.baud			= 400000,
	.wake_delay				= 800,
	.rx_retries				= 20,
	.cfg_data              = &I2C_0
};

/* Local function prototype section ----------------------------------*/
void TestPorting(void);
void print_bytes(uint8_t * ptr, uint8_t length);

int main(void)
{
	int i;
	uint8_t *addr_b;
	addr_b = (uint8_t*)&TRAM->RAM[0].reg;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	printf("helllo world\r\n");
	
	sc_RTC_Init();
	sc_TRAM_Init();
	sc_TRAM_Fill(0x05);
	
	TestPorting();
	/* Replace with your application code */
	while (1) {
		
		delay_ms(2000);
		for (i=0; i < 128; i=i+2)
		{
			if (i%16 == 0)
			{
				printf("\r\n");
			}
			printf("0x%02x%02x ",*(addr_b+i),*(addr_b+i+1));
		}
	}
}

void print_bytes(uint8_t * ptr, uint8_t length)
{
	
	uint8_t i = 0;
	uint8_t line_count = 0;
	for(;i < length; i++) {
		printf("0x%02x, ",ptr[i]);
		line_count++;
		if(line_count == 8) {
			printf("\r\n");
			line_count = 0;
		}
	}
	
	printf("\r\n");
}

void TestPorting(void)
{
	printf("\x1b[2J");
	printf("Test Porting\r\n");
	
	volatile ATCA_STATUS status;

	status = atcab_init( &cfg_ateccx08a_i2c_host );
	CHECK_STATUS(status);
	printf("Device init complete\n\r");

	/*Getting serial from host*/
	uint8_t serial_number[ATCA_SERIAL_NUM_SIZE];
	
	status = atcab_read_serial_number((uint8_t*)&serial_number);
	CHECK_STATUS(status);
	printf("Serial Number of host\r\n");
	print_bytes((uint8_t*)&serial_number, 9);
	printf("\r\n");
}