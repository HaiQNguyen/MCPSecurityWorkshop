#include <atmel_start.h>



/* NOTE RTC and tamper pin PA08 will be initialized manually because they are not supported by Atmel START*/

void RTC_Init(void);



int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	printf("helllo world\r\n");
	
	uint32_t i;
	uint32_t tram_src_data[3] = {0x12345678, 0xAABBCCDD, 0x55AAABCD};
	uint32_t tram_chk_data[3];

	/* Write data to TRAM */
	for (i = 0; i < 3; i++) {
		TRUST_RAM_0_write(i, tram_src_data[i]);
	}

	/* Read data from TRAM */
	for (i = 0; i < 3; i++) {
		tram_chk_data[i] = TRUST_RAM_0_read(i);
	}
	
	/* Replace with your application code */
	while (1) {
		
		delay_ms(2000);
		for (i = 0; i < 3; i++) {
			tram_chk_data[i] = TRUST_RAM_0_read(i);
			printf( "data[%d]: %d \r\n", (int)i, (int)tram_chk_data[i]);
		}
	}
}

void RTC_Init(void)
{
	/* Configure PA08 as RTC IN0 (peripheral I) */
	PORT_SEC->Group[0].WRCONFIG.reg = (uint32_t)(PORT_WRCONFIG_WRPINCFG|PORT_WRCONFIG_WRPMUX|PORT_WRCONFIG_PINMASK(1<<8)|PORT_WRCONFIG_PMUXEN|PORT_WRCONFIG_PMUX(8));
	
	/* Set APB Clock */
	MCLK->APBAMASK.reg |= MCLK_APBAMASK_RTC;
	
	/* Select RTC clock on XOSC32K */
	OSC32KCTRL->RTCCTRL.reg = OSC32KCTRL_RTCCTRL_RTCSEL_ULP1K;
	
	/* Reset RTC */
	RTC->MODE0.CTRLA.reg = RTC_MODE0_CTRLA_SWRST;
	while(RTC->MODE0.SYNCBUSY.bit.SWRST);
	
	RTC->MODE0.CTRLA.reg = (RTC_MODE0_CTRLA_MODE_COUNT32 | RTC_MODE0_CTRLA_PRESCALER_DIV1 | RTC_MODE0_CTRLA_COUNTSYNC);
	
	/*Configure RTC Tamper on IN0 */
	RTC->MODE0.TAMPCTRL.reg = ( RTC_TAMPCTRL_IN0ACT_WAKE | 	// Tamper action : Wake and set Tamper flag
	RTC_TAMPCTRL_TAMLVL0 |		// Tamper edge : rising
	RTC_TAMPCTRL_DEBNC0	 		// Tamper Debounce  :Detect edge with synchronous stability
	);
	
	/* Enable Tamper event output*/
	RTC->MODE0.EVCTRL.reg = (RTC_MODE0_EVCTRL_TAMPEREO | RTC_MODE0_EVCTRL_OVFEO);
	
	/* Enable RTC */
	RTC->MODE0.CTRLA.reg |= RTC_MODE0_CTRLA_ENABLE;
	while(RTC->MODE0.SYNCBUSY.bit.ENABLE);
}