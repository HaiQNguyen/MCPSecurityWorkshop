/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

/**
 * Example of using TARGET_IO to write "Hello World" using the IO abstraction.
 */
void TARGET_IO_example(void)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&TARGET_IO, &io);
	usart_sync_enable(&TARGET_IO);

	io_write(io, (uint8_t *)"Hello World!", 12);
}

/**
 * Example of using TRUST_RAM_0 to read and write security RAM.
 */
void TRUST_RAM_0_example(void)
{
	uint32_t i;
	uint32_t tram_src_data[3] = {0x12345678, 0xAABBCCDD, 0x55AAABCD};
	uint32_t tram_chk_data[3];

	/* Write data to TRAM */
	for (i = 0; i < 3; i++) {
		TRUST_RAM_0_write(i, tram_src_data[i]);
	}

	/* Read data from TRAM */
	for (i = 0; i < 3; i++) {
		tram_chk_data[i] = TRUST_RAM_0_read(i);
	}

	/* Check data */
	for (i = 0; i < 3; i++) {
		if (tram_src_data[i] != tram_chk_data[i]) {
			while (1)
				; /* Error happen */
		}
	}
}
