/*
 * Secure_Functions.h
 *
 * Created: 22/05/2019 13:41:04
 *  Author: haing
 */ 

#include <atmel_start.h>

#ifndef SECURE_FUNCTIONS_H_
#define SECURE_FUNCTIONS_H_


void sc_RTC_Init(void);
void sc_TRAM_Write(uint8_t * data, uint8_t size, uint8_t offset);
void sc_TRAM_Read(uint8_t * data, uint8_t size, uint8_t offset);
void sc_TRAM_Init(void);
void sc_ConsolePuts (uint8_t * string);
void nsc_ConsolePuts (uint8_t * string);
void nsc_PrintBytes(uint8_t * ptr, uint8_t length); 
void nsc_GetRevSerialNumber(uint8_t *serial_buff, uint8_t serial_size, uint8_t * rev_buff, uint8_t rev_size); 


#endif /* SECURE_FUNCTIONS_H_ */