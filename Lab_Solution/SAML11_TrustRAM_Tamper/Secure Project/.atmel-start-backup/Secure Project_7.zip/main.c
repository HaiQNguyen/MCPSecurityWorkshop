#include <atmel_start.h>
#include "Secure_functions/Secure_Functions.h"
#include "cryptoauthlib.h"
#include "atca_host.h"

/* NOTE RTC and tamper pin PA08 will be initialized manually because they are not supported by Atmel START*/


/* Define section ---------------------------------------------------*/

/* TZ_START_NS: Start address of non-secure application */
#define TZ_START_NS 0x00008000



#define CHECK_STATUS(s)										\
if(s != ATCA_SUCCESS) {										\
	printf("status code: 0x%x\r\n", s);						\
	printf("Error: Line %d in %s\r\n", __LINE__, __FILE__); \
	while(1);												\
}


/* Local variable section --------------------------------------------*/

/* typedef for non-secure callback functions */
typedef void (*ns_funcptr_void) (void) __attribute__((cmse_nonsecure_call));

ATCAIfaceCfg cfg_ateccx08a_i2c_host = {
	.iface_type				= ATCA_I2C_IFACE,
	.devtype				= ATECC608A,
	.atcai2c.slave_address	= 0xC0,
	.atcai2c.bus			= 1,
	.atcai2c.baud			= 400000,
	.wake_delay				= 800,
	.rx_retries				= 20,
	.cfg_data              = &I2C_0
};

/* Local function prototype section ----------------------------------*/


int main(void)
{
	
	volatile ATCA_STATUS status;
	uint8_t serial_number[ATCA_SERIAL_NUM_SIZE];
	uint8_t revision_number[4];

	
	/* Pointer to Non secure reset handler definition*/
	ns_funcptr_void NonSecure_ResetHandler;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	sc_ConsolePuts("hello world\r\n");
	
	sc_RTC_Init();
	sc_TRAM_Init();
	
	status = atcab_init( &cfg_ateccx08a_i2c_host );
	CHECK_STATUS(status);
	
	sc_ConsolePuts("Initializing ATECC508\r\n");
	status = atcab_read_serial_number((uint8_t*)&serial_number);
	CHECK_STATUS(status);

	status = atcab_info(revision_number);
	CHECK_STATUS(status);
	
	sc_TRAM_Write(serial_number, ATCA_SERIAL_NUM_SIZE, 0x00);
	sc_TRAM_Write(revision_number, 4, 0x00 + ATCA_SERIAL_NUM_SIZE);
	
	sc_ConsolePuts("ATECC508 is initialized. Revision and serial number are stored in Trust Ram\r\n");
	
	/* - Set non-secure main stack (MSP_NS) */
	__TZ_set_MSP_NS(*((uint32_t *)(TZ_START_NS)));
	
	/* - Get non-secure reset handler */
	NonSecure_ResetHandler = (ns_funcptr_void)(*((uint32_t *)((TZ_START_NS) + 4U)));
	
	/* - Start Non-secure Application */
	NonSecure_ResetHandler();
	
	
	/* Replace with your application code */
	while (1) {
		
		
	}
}
