#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	printf("helllo wprld\r\n");
	/* Replace with your application code */
	while (1) {
	}
}
